package com.kammari.util;

public enum BrowserType {
    Chrome,
    IE,
    Firefox,
    UseDefault //We default to Firefox
}
