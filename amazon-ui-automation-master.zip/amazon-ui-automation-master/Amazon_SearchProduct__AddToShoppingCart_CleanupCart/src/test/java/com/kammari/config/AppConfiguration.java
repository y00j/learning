package com.kammari.config;




public class AppConfiguration extends Configuration {
    public static String BaseUrl = "https://www.amazon.com/";
    public static String Email = "<Your Amazon Email Here>";
    public static String Password = "<Your Amazon Password Here>";

    public static String ProductPartialName = "My First ABC (My First Books)";


}
